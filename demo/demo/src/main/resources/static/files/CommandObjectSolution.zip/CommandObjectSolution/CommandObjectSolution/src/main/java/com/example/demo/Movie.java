package com.example.demo;

public class Movie {
    private String title;
    private String director;
    private String genre;
    private Boolean forChildren;

    public Movie() {
    }

    public Movie(String title, String director) {
        this.title = title;
        this.director = director;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public Boolean getForChildren() {
        return forChildren;
    }

    public void setForChildren(Boolean forChildren) {
        this.forChildren = forChildren;
    }
}
