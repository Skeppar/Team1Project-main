package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class DemoController {

    // Task 1
    @GetMapping("/task1")
    public String level1(Model model){
        model.addAttribute(new Movie());
        return "task1";
    }

    @PostMapping("/task1")
    public String submit(Model model, @RequestParam String title, @RequestParam String director) {
        Movie movie = new Movie(title, director);
        model.addAttribute("movie", movie);
        return "task1";
    }

    // Task 2
    @GetMapping("/task2")
    public String command(Model model){
        model.addAttribute("movie", new Movie());
        return "task2";
    }

    @PostMapping("/task2")
    public String commandsubmit(@ModelAttribute Movie movie, Model model){
        model.addAttribute(movie);
        return "task2";
    }

    // Task 3
    @GetMapping("/task3")
    public String task3(Model model){
        model.addAttribute("movie", new Movie());
        return "task3";
    }

    @PostMapping("/task3")
    public String task3submit(@ModelAttribute Movie movie, Model model){
        model.addAttribute("movie", movie);
        return "task3";
    }
}
